<?php
$host = 'localhost'; // адрес сервера 
$database = 'my'; // имя базы данных
$user = 'root'; // имя пользователя
$password = ''; // пароль
?>